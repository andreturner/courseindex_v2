function setup() {
    createCanvas(1000, 1000);
    blendMode(LIGHTEST);
    }

    function draw() {
        background(255, 100, 100);


        fill(150, 180, 80);
        ellipse(500, 500, 250);

        fill(0, 170, 50);
    rect(650, 300, 100, 400);

    fill(90, 150, 150);
    ellipse(500, 500, 400);
    }